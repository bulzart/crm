<?php $__env->startSection('content'); ?>

    <h4><?php echo e($leads->name); ?></h4>
    <p><?php echo e($leads->address); ?></p>
<div>
    <h4><?php echo e($leads->count); ?></h4>
    <label>Personen</label>
</div>
    <div>
        <span><?php echo e($leads->created_at); ?></span>
    </div>
<div>
    <form method="POST" action="<?php echo e(route('deletedlead',$leads->id)); ?>">
        <?php echo csrf_field(); ?>
        <h5>Kein Termin Vereinbart</h5>
        <span>Begrundung: </span>
        <input type="text" name="reason" class="form-contorl">
        <br>
        <label>Komentar: </label>
        <input type="text" name="comment" class="form-control">

        <input type="submit" value="Save" class="btn btn-info">
    </form>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kutiza\crm\resources\views/deletedlead.blade.php ENDPATH**/ ?>