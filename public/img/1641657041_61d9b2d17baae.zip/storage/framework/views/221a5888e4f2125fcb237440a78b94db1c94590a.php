
<?php $__env->startSection('content'); ?>
<form action="<?php echo e(route('asignlead',$lead->id)); ?>" method="post">
    <?php echo csrf_field(); ?>
<div class="form-group container text-center pt-4">
  <fieldset disabled>
      <label for="disabledTextInput">Name</label>
      <input type="text" id="disabledTextInput" class="form-control" value="<?php echo e($lead->name); ?>">

    <div class="form-group">
      <label for="disabledSelect">People</label>
      <input type="number" value="<?php echo e($lead->count); ?>" class="form-control">
      <label>Came from</label>
      <input type="text" value="<?php echo e($lead->comefrom); ?>" class="form-control">
    </div>

  </fieldset>
  <label>Appointment date</label>
  <br>
  <input type="date" class="col-12 text-center" name="appointmentdate">
</br>
<label>Time</label>
<input type="time" name="apptime" class="text-center col-12">
  <label>Asign to:</label>
  <div class="justify-content-end d-flex">
  <i class="fas fa-filter" style="cursor: pointer;" title="Filter" data-bs-toggle="modal" data-bs-target="#exampleModal"></i>
</div>
<br>
  <select name="admin" class="form-control">
      <?php $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <option value="<?php echo e($admin->id); ?>"><?php echo e($admin->name); ?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </select>


  <input type="submit" class="btn btn-primary mt-2" value="Appointment">
</form>

<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Filter</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">

      <form method="post" class="form-control">

 

    <?php echo csrf_field(); ?>
    <label>Name like</label>
<input type="text" name="name" class="form-control">

  <h5 class="h5">Quality</h5>

  <div class="d-inline d-flex">
<input type="date" name="from" class="form-control">
<input type="date" name="now" class="form-control">
</div>



<br>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <input type="submit" class="btn btn-primary" value="Filter">
      </div>
      </form>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kutiza\crm\resources\views/alead.blade.php ENDPATH**/ ?>