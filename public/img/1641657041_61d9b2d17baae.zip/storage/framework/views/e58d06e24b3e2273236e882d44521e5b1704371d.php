
<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
<div class="col-md-4 col-12" style="background: #f7f7f7; border-radius: 25px;">
<span class="mt-2">Offene Aufgaben</span>
<span class="text-danger"><?php echo e($opencnt); ?></span><br>

<?php $__currentLoopData = $realopen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<a style="underline: none"href="<?php echo e(route('document',$task->id)); ?>"><div class="p-1" style="background: white; border-radius: 12px;">


<h5 class="m-1"><?php echo e(ucfirst($task->name)); ?> <?php echo e(ucfirst($task->lname)); ?></h5>
<span class="m-1">Kommentar: <?php echo e($task->status); ?></span>


</div></a>
<br>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<div class="col-md-4 col-12" style="background: #ffebe5; border-radius: 25px;">
    <span class="mt-2">Pending</span>
    <span class="text-danger"><?php echo e($pendingcnt); ?></span>
<?php $__currentLoopData = $pending; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<a href="<?php echo e(route('document',$task->id)); ?>"><div class="p-1" style="background: white; border-radius: 12px;">
<h5 class="m-1"><?php echo e(ucfirst($task->name)); ?> <?php echo e(ucfirst($task->lname)); ?></h5>

<span class="m-1">Kommentar: <?php echo e($task->status); ?></span>
</div></a>
<br>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<br>
<div class="col-md-4 col-12" style="border-radius: 25px;">
<p class="text-center">Costumer birthdays today:</p>
<br>
<?php $__currentLoopData = $birthdays; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $birth): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="p-1" style="background: #f7f7f7; border-radius: 12px;">
<i class="fas fa-birthday-cake" style="font-size: 33px;"></i>
<span class="h5"><?php echo e($birth['name']); ?> <?php echo e($birth['lname']); ?></span>
<br>
<?php echo e($birth['birthday']); ?> (<?php echo e($birth['age']); ?> Jahre)
</div>
<br>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kutiza\crm\resources\views/tasks.blade.php ENDPATH**/ ?>