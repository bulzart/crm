<html xmlns="http://www.w3.org/1999/html" xmlns="http://www.w3.org/1999/html">

<?php $__env->startSection('content'); ?>
    <div class="form-group ">
        <a class="btn btn-info" onclick="openHealth()">KK</a>
        <a class="btn btn-info" onclick="openCar()">A</a>
        <a class="btn btn-info" onclick="openFinance()">S</a>
        <a class="btn btn-info" onclick="openMore()">S</a>
        <form method="POST" action="<?php echo e(route('documentform',$id)); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="count" id="count">
            <div style="display: none" id="health">
                <div>
                    <label>Preinsurer</label>
                    <?php if(isset($data->preinsurer)): ?>

                        <a href="<?php echo e(\Storage::disk('img')->url(substr($data->preinsurer,4))); ?>" target="_blank"><?php echo e($data->preinsurer); ?></a>

                        <input class="form-control" type="file" value="<?php echo e($data->preinsurer); ?>" name="preinsurer">
                    <?php else: ?>
                        <input class="form-control" type="file" name="preinsurer">
                    <?php endif; ?>
                </div>
                <div>

                    <label>Id necessary</label>
                    <?php if(isset($data->idnecessary)): ?>

                        <a href="<?php echo e(\Storage::disk('img')->url(substr($data->idnecessary,4))); ?>" target="_blank"><?php echo e($data->idnecessary); ?></a>

                        <input class="form-control" type="file" value="<?php echo e($data->idnecessary); ?>" name="idnecessary">
                    <?php else: ?>
                        <input class="form-control" type="file" name="idnecessary">
                    <?php endif; ?>
                </div>
                <div>
                    <label>Notice By</label>
                    <?php if(isset($data->noticeby)): ?>
                        <input class="form-control" type="file" value="<?php echo e($data->noticeby); ?>" name="noticeby">
                    <?php else: ?>
                        <input class="form-control" type="file" name="noticeby">
                    <?php endif; ?>
                </div>
                <div>
                    <label>Power of attorney</label>
                    <?php if(isset($data->powerofattorney)): ?>
                        <input class="form-control" type="file" name="powerofattorney" value="<?php echo e($data->powerofattorney); ?>">
                    <?php else: ?>
                        <input class="form-control" type="file" name="powerofattorney">
                    <?php endif; ?>

                </div>

            </div>

            <br>
            <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
            <div style="display: none" id="car">
                <input onclick="openCounterOffer()" class="btn btn-primary" type="button" value="Counter">
                <input onclick="openNewVehicle()" class="btn btn-secondary" type="button" value="New Vehicle">
                <hr>


                <div class="" id="counteroffer">

                </div>

                <div  id="newVehicle">



                </div>
                <div id="anotherNewVehicle">


                <div>
                    <label>Employment Relationship: </label>
                    <select name="employmentrelationship">
                        <?php if(isset($data->employmentrelationship)): ?> <option selected value="<?php echo e($data->employmentrelationship); ?>"><?php echo e($data->employmentrelationship); ?></option> <?php endif; ?>
                        <option>Coworkers</option>
                        <option>Team Members</option>
                        <option>Work Friends</option>
                        <option>Manager/Direct Report</option>
                        <option>Office Spouse</option>
                        <option>Mentor/Mentee</option>
                        <option>Life Friends</option>
                    </select>
                </div>
                <div>
                    <?php if(isset($data->job)): ?>
                    <label>Job: </label>
                    <input type="text" name="job" class="form-control" value="<?php echo e($data->job); ?>">
                    <?php else: ?>
                    <input type="text" name="job" class="form-control">
                    <?php endif; ?>

                </div>

            </div>


            <div style="display: none" id="finance">
                <hr>
                <h4>3a/3b Request</h4>
                <div>

                    <label>Nationality</label>
                    <select name="nationalityfinance">

                        <?php if(isset($data->nationalityfinance)): ?><option value="<?php echo e($data->nationalityfinance); ?>" selected><?php echo e($data->nationalityfinance); ?></option><?php endif; ?>
                        <option value="afghan">Afghan</option>
                        <option value="albanian">Albanian</option>
                        <option value="algerian">Algerian</option>
                        <option value="american">American</option>
                        <option value="andorran">Andorran</option>
                        <option value="angolan">Angolan</option>
                        <option value="antiguans">Antiguans</option>
                        <option value="argentinean">Argentinean</option>
                        <option value="armenian">Armenian</option>
                        <option value="australian">Australian</option>
                        <option value="austrian">Austrian</option>
                        <option value="azerbaijani">Azerbaijani</option>
                        <option value="bahamian">Bahamian</option>
                        <option value="bahraini">Bahraini</option>
                        <option value="bangladeshi">Bangladeshi</option>
                        <option value="barbadian">Barbadian</option>
                        <option value="barbudans">Barbudans</option>
                        <option value="batswana">Batswana</option>
                        <option value="belarusian">Belarusian</option>
                        <option value="belgian">Belgian</option>
                        <option value="belizean">Belizean</option>
                        <option value="beninese">Beninese</option>
                        <option value="bhutanese">Bhutanese</option>
                        <option value="bolivian">Bolivian</option>
                        <option value="bosnian">Bosnian</option>
                        <option value="brazilian">Brazilian</option>
                        <option value="british">British</option>
                        <option value="bruneian">Bruneian</option>
                        <option value="bulgarian">Bulgarian</option>
                        <option value="burkinabe">Burkinabe</option>
                        <option value="burmese">Burmese</option>
                        <option value="burundian">Burundian</option>
                        <option value="cambodian">Cambodian</option>
                        <option value="cameroonian">Cameroonian</option>
                        <option value="canadian">Canadian</option>
                        <option value="cape verdean">Cape Verdean</option>
                        <option value="central african">Central African</option>
                        <option value="chadian">Chadian</option>
                        <option value="chilean">Chilean</option>
                        <option value="chinese">Chinese</option>
                        <option value="colombian">Colombian</option>
                        <option value="comoran">Comoran</option>
                        <option value="congolese">Congolese</option>
                        <option value="costa rican">Costa Rican</option>
                        <option value="croatian">Croatian</option>
                        <option value="cuban">Cuban</option>
                        <option value="cypriot">Cypriot</option>
                        <option value="czech">Czech</option>
                        <option value="danish">Danish</option>
                        <option value="djibouti">Djibouti</option>
                        <option value="dominican">Dominican</option>
                        <option value="dutch">Dutch</option>
                        <option value="east timorese">East Timorese</option>
                        <option value="ecuadorean">Ecuadorean</option>
                        <option value="egyptian">Egyptian</option>
                        <option value="emirian">Emirian</option>
                        <option value="equatorial guinean">Equatorial Guinean</option>
                        <option value="eritrean">Eritrean</option>
                        <option value="estonian">Estonian</option>
                        <option value="ethiopian">Ethiopian</option>
                        <option value="fijian">Fijian</option>
                        <option value="filipino">Filipino</option>
                        <option value="finnish">Finnish</option>
                        <option value="french">French</option>
                        <option value="gabonese">Gabonese</option>
                        <option value="gambian">Gambian</option>
                        <option value="georgian">Georgian</option>
                        <option value="german">German</option>
                        <option value="ghanaian">Ghanaian</option>
                        <option value="greek">Greek</option>
                        <option value="grenadian">Grenadian</option>
                        <option value="guatemalan">Guatemalan</option>
                        <option value="guinea-bissauan">Guinea-Bissauan</option>
                        <option value="guinean">Guinean</option>
                        <option value="guyanese">Guyanese</option>
                        <option value="haitian">Haitian</option>
                        <option value="herzegovinian">Herzegovinian</option>
                        <option value="honduran">Honduran</option>
                        <option value="hungarian">Hungarian</option>
                        <option value="icelander">Icelander</option>
                        <option value="indian">Indian</option>
                        <option value="indonesian">Indonesian</option>
                        <option value="iranian">Iranian</option>
                        <option value="iraqi">Iraqi</option>
                        <option value="irish">Irish</option>
                        <option value="israeli">Israeli</option>
                        <option value="italian">Italian</option>
                        <option value="ivorian">Ivorian</option>
                        <option value="jamaican">Jamaican</option>
                        <option value="japanese">Japanese</option>
                        <option value="jordanian">Jordanian</option>
                        <option value="kazakhstani">Kazakhstani</option>
                        <option value="kenyan">Kenyan</option>
                        <option value="kittian and nevisian">Kittian and Nevisian</option>
                        <option value="kuwaiti">Kuwaiti</option>
                        <option value="kyrgyz">Kyrgyz</option>
                        <option value="laotian">Laotian</option>
                        <option value="latvian">Latvian</option>
                        <option value="lebanese">Lebanese</option>
                        <option value="liberian">Liberian</option>
                        <option value="libyan">Libyan</option>
                        <option value="liechtensteiner">Liechtensteiner</option>
                        <option value="lithuanian">Lithuanian</option>
                        <option value="luxembourger">Luxembourger</option>
                        <option value="macedonian">Macedonian</option>
                        <option value="malagasy">Malagasy</option>
                        <option value="malawian">Malawian</option>
                        <option value="malaysian">Malaysian</option>
                        <option value="maldivan">Maldivan</option>
                        <option value="malian">Malian</option>
                        <option value="maltese">Maltese</option>
                        <option value="marshallese">Marshallese</option>
                        <option value="mauritanian">Mauritanian</option>
                        <option value="mauritian">Mauritian</option>
                        <option value="mexican">Mexican</option>
                        <option value="micronesian">Micronesian</option>
                        <option value="moldovan">Moldovan</option>
                        <option value="monacan">Monacan</option>
                        <option value="mongolian">Mongolian</option>
                        <option value="moroccan">Moroccan</option>
                        <option value="mosotho">Mosotho</option>
                        <option value="motswana">Motswana</option>
                        <option value="mozambican">Mozambican</option>
                        <option value="namibian">Namibian</option>
                        <option value="nauruan">Nauruan</option>
                        <option value="nepalese">Nepalese</option>
                        <option value="new zealander">New Zealander</option>
                        <option value="ni-vanuatu">Ni-Vanuatu</option>
                        <option value="nicaraguan">Nicaraguan</option>
                        <option value="nigerien">Nigerien</option>
                        <option value="north korean">North Korean</option>
                        <option value="northern irish">Northern Irish</option>
                        <option value="norwegian">Norwegian</option>
                        <option value="omani">Omani</option>
                        <option value="pakistani">Pakistani</option>
                        <option value="palauan">Palauan</option>
                        <option value="panamanian">Panamanian</option>
                        <option value="papua new guinean">Papua New Guinean</option>
                        <option value="paraguayan">Paraguayan</option>
                        <option value="peruvian">Peruvian</option>
                        <option value="polish">Polish</option>
                        <option value="portuguese">Portuguese</option>
                        <option value="qatari">Qatari</option>
                        <option value="romanian">Romanian</option>
                        <option value="russian">Russian</option>
                        <option value="rwandan">Rwandan</option>
                        <option value="saint lucian">Saint Lucian</option>
                        <option value="salvadoran">Salvadoran</option>
                        <option value="samoan">Samoan</option>
                        <option value="san marinese">San Marinese</option>
                        <option value="sao tomean">Sao Tomean</option>
                        <option value="saudi">Saudi</option>
                        <option value="scottish">Scottish</option>
                        <option value="senegalese">Senegalese</option>
                        <option value="serbian">Serbian</option>
                        <option value="seychellois">Seychellois</option>
                        <option value="sierra leonean">Sierra Leonean</option>
                        <option value="singaporean">Singaporean</option>
                        <option value="slovakian">Slovakian</option>
                        <option value="slovenian">Slovenian</option>
                        <option value="solomon islander">Solomon Islander</option>
                        <option value="somali">Somali</option>
                        <option value="south african">South African</option>
                        <option value="south korean">South Korean</option>
                        <option value="spanish">Spanish</option>
                        <option value="sri lankan">Sri Lankan</option>
                        <option value="sudanese">Sudanese</option>
                        <option value="surinamer">Surinamer</option>
                        <option value="swazi">Swazi</option>
                        <option value="swedish">Swedish</option>
                        <option value="swiss">Swiss</option>
                        <option value="syrian">Syrian</option>
                        <option value="taiwanese">Taiwanese</option>
                        <option value="tajik">Tajik</option>
                        <option value="tanzanian">Tanzanian</option>
                        <option value="thai">Thai</option>
                        <option value="togolese">Togolese</option>
                        <option value="tongan">Tongan</option>
                        <option value="trinidadian or tobagonian">Trinidadian or Tobagonian</option>
                        <option value="tunisian">Tunisian</option>
                        <option value="turkish">Turkish</option>
                        <option value="tuvaluan">Tuvaluan</option>
                        <option value="ugandan">Ugandan</option>
                        <option value="ukrainian">Ukrainian</option>
                        <option value="uruguayan">Uruguayan</option>
                        <option value="uzbekistani">Uzbekistani</option>
                        <option value="venezuelan">Venezuelan</option>
                        <option value="vietnamese">Vietnamese</option>
                        <option value="welsh">Welsh</option>
                        <option value="yemenite">Yemenite</option>
                        <option value="zambian">Zambian</option>
                        <option value="zimbabwean">Zimbabwean</option>

                    <label>Payment Rhythm</label>
                    <select name="paymentrhythm">
                        <?php if(isset($data->paymentrhythm)): ?><option selected value="<?php echo e($data->paymentrhythm); ?>"><?php echo e($data->paymentrhythm); ?></option><?php endif; ?>
                        <option>Weekly</option>
                        <option>Mounth</option>
                        <option>Year</option>

                    </select>
                </div>
                <div>
                    <label>Residence Permit</label>
                    <?php if(isset($data->residencepermit)): ?>
                        <input type="text" class="form-control" name="residencepermit" value="<?php echo e($data->residencepermit); ?>">
                    <?php else: ?>
                        <input type="text" class="form-control" name="residencepermit">
                    <?php endif; ?>

                </div>
                <div>
                    <label>Phone Number: </label>
                    <div class="d-inline">

                        <select name="countryCode">

                            <option data-countryCode="GB" value="44" selected>UK (+44)</option>
                            <option data-countryCode="US" value="1">USA (+1)</option>
                            <optgroup label="Other countries">
                                <option data-countryCode="DZ" value="213">Algeria (+213)</option>
                                <option data-countryCode="AD" value="376">Andorra (+376)</option>
                                <option data-countryCode="AO" value="244">Angola (+244)</option>
                                <option data-countryCode="AI" value="1264">Anguilla (+1264)</option>
                                <option data-countryCode="AG" value="1268">Antigua &amp; Barbuda (+1268)</option>
                                <option data-countryCode="AR" value="54">Argentina (+54)</option>
                                <option data-countryCode="AM" value="374">Armenia (+374)</option>
                                <option data-countryCode="AW" value="297">Aruba (+297)</option>
                                <option data-countryCode="AU" value="61">Australia (+61)</option>
                                <option data-countryCode="AT" value="43">Austria (+43)</option>
                                <option data-countryCode="AZ" value="994">Azerbaijan (+994)</option>
                                <option data-countryCode="BS" value="1242">Bahamas (+1242)</option>
                                <option data-countryCode="BH" value="973">Bahrain (+973)</option>
                                <option data-countryCode="BD" value="880">Bangladesh (+880)</option>
                                <option data-countryCode="BB" value="1246">Barbados (+1246)</option>
                                <option data-countryCode="BY" value="375">Belarus (+375)</option>
                                <option data-countryCode="BE" value="32">Belgium (+32)</option>
                                <option data-countryCode="BZ" value="501">Belize (+501)</option>
                                <option data-countryCode="BJ" value="229">Benin (+229)</option>
                                <option data-countryCode="BM" value="1441">Bermuda (+1441)</option>
                                <option data-countryCode="BT" value="975">Bhutan (+975)</option>
                                <option data-countryCode="BO" value="591">Bolivia (+591)</option>
                                <option data-countryCode="BA" value="387">Bosnia Herzegovina (+387)</option>
                                <option data-countryCode="BW" value="267">Botswana (+267)</option>
                                <option data-countryCode="BR" value="55">Brazil (+55)</option>
                                <option data-countryCode="BN" value="673">Brunei (+673)</option>
                                <option data-countryCode="BG" value="359">Bulgaria (+359)</option>
                                <option data-countryCode="BF" value="226">Burkina Faso (+226)</option>
                                <option data-countryCode="BI" value="257">Burundi (+257)</option>
                                <option data-countryCode="KH" value="855">Cambodia (+855)</option>
                                <option data-countryCode="CM" value="237">Cameroon (+237)</option>
                                <option data-countryCode="CA" value="1">Canada (+1)</option>
                                <option data-countryCode="CV" value="238">Cape Verde Islands (+238)</option>
                                <option data-countryCode="KY" value="1345">Cayman Islands (+1345)</option>
                                <option data-countryCode="CF" value="236">Central African Republic (+236)</option>
                                <option data-countryCode="CL" value="56">Chile (+56)</option>
                                <option data-countryCode="CN" value="86">China (+86)</option>
                                <option data-countryCode="CO" value="57">Colombia (+57)</option>
                                <option data-countryCode="KM" value="269">Comoros (+269)</option>
                                <option data-countryCode="CG" value="242">Congo (+242)</option>
                                <option data-countryCode="CK" value="682">Cook Islands (+682)</option>
                                <option data-countryCode="CR" value="506">Costa Rica (+506)</option>
                                <option data-countryCode="HR" value="385">Croatia (+385)</option>
                                <option data-countryCode="CU" value="53">Cuba (+53)</option>
                                <option data-countryCode="CY" value="90392">Cyprus North (+90392)</option>
                                <option data-countryCode="CY" value="357">Cyprus South (+357)</option>
                                <option data-countryCode="CZ" value="42">Czech Republic (+42)</option>
                                <option data-countryCode="DK" value="45">Denmark (+45)</option>
                                <option data-countryCode="DJ" value="253">Djibouti (+253)</option>
                                <option data-countryCode="DM" value="1809">Dominica (+1809)</option>
                                <option data-countryCode="DO" value="1809">Dominican Republic (+1809)</option>
                                <option data-countryCode="EC" value="593">Ecuador (+593)</option>
                                <option data-countryCode="EG" value="20">Egypt (+20)</option>
                                <option data-countryCode="SV" value="503">El Salvador (+503)</option>
                                <option data-countryCode="GQ" value="240">Equatorial Guinea (+240)</option>
                                <option data-countryCode="ER" value="291">Eritrea (+291)</option>
                                <option data-countryCode="EE" value="372">Estonia (+372)</option>
                                <option data-countryCode="ET" value="251">Ethiopia (+251)</option>
                                <option data-countryCode="FK" value="500">Falkland Islands (+500)</option>
                                <option data-countryCode="FO" value="298">Faroe Islands (+298)</option>
                                <option data-countryCode="FJ" value="679">Fiji (+679)</option>
                                <option data-countryCode="FI" value="358">Finland (+358)</option>
                                <option data-countryCode="FR" value="33">France (+33)</option>
                                <option data-countryCode="GF" value="594">French Guiana (+594)</option>
                                <option data-countryCode="PF" value="689">French Polynesia (+689)</option>
                                <option data-countryCode="GA" value="241">Gabon (+241)</option>
                                <option data-countryCode="GM" value="220">Gambia (+220)</option>
                                <option data-countryCode="GE" value="7880">Georgia (+7880)</option>
                                <option data-countryCode="DE" value="49">Germany (+49)</option>
                                <option data-countryCode="GH" value="233">Ghana (+233)</option>
                                <option data-countryCode="GI" value="350">Gibraltar (+350)</option>
                                <option data-countryCode="GR" value="30">Greece (+30)</option>
                                <option data-countryCode="GL" value="299">Greenland (+299)</option>
                                <option data-countryCode="GD" value="1473">Grenada (+1473)</option>
                                <option data-countryCode="GP" value="590">Guadeloupe (+590)</option>
                                <option data-countryCode="GU" value="671">Guam (+671)</option>
                                <option data-countryCode="GT" value="502">Guatemala (+502)</option>
                                <option data-countryCode="GN" value="224">Guinea (+224)</option>
                                <option data-countryCode="GW" value="245">Guinea - Bissau (+245)</option>
                                <option data-countryCode="GY" value="592">Guyana (+592)</option>
                                <option data-countryCode="HT" value="509">Haiti (+509)</option>
                                <option data-countryCode="HN" value="504">Honduras (+504)</option>
                                <option data-countryCode="HK" value="852">Hong Kong (+852)</option>
                                <option data-countryCode="HU" value="36">Hungary (+36)</option>
                                <option data-countryCode="IS" value="354">Iceland (+354)</option>
                                <option data-countryCode="IN" value="91">India (+91)</option>
                                <option data-countryCode="ID" value="62">Indonesia (+62)</option>
                                <option data-countryCode="IR" value="98">Iran (+98)</option>
                                <option data-countryCode="IQ" value="964">Iraq (+964)</option>
                                <option data-countryCode="IE" value="353">Ireland (+353)</option>
                                <option data-countryCode="IL" value="972">Israel (+972)</option>
                                <option data-countryCode="IT" value="39">Italy (+39)</option>
                                <option data-countryCode="JM" value="1876">Jamaica (+1876)</option>
                                <option data-countryCode="JP" value="81">Japan (+81)</option>
                                <option data-countryCode="JO" value="962">Jordan (+962)</option>
                                <option data-countryCode="KZ" value="7">Kazakhstan (+7)</option>
                                <option data-countryCode="KE" value="254">Kenya (+254)</option>
                                <option data-countryCode="KI" value="686">Kiribati (+686)</option>
                                <option data-countryCode="KP" value="850">Korea North (+850)</option>
                                <option data-countryCode="KR" value="82">Korea South (+82)</option>
                                <option data-countryCode="KW" value="965">Kuwait (+965)</option>
                                <option data-countryCode="KG" value="996">Kyrgyzstan (+996)</option>
                                <option data-countryCode="LA" value="856">Laos (+856)</option>
                                <option data-countryCode="LV" value="371">Latvia (+371)</option>
                                <option data-countryCode="LB" value="961">Lebanon (+961)</option>
                                <option data-countryCode="LS" value="266">Lesotho (+266)</option>
                                <option data-countryCode="LR" value="231">Liberia (+231)</option>
                                <option data-countryCode="LY" value="218">Libya (+218)</option>
                                <option data-countryCode="LI" value="417">Liechtenstein (+417)</option>
                                <option data-countryCode="LT" value="370">Lithuania (+370)</option>
                                <option data-countryCode="LU" value="352">Luxembourg (+352)</option>
                                <option data-countryCode="MO" value="853">Macao (+853)</option>
                                <option data-countryCode="MK" value="389">Macedonia (+389)</option>
                                <option data-countryCode="MG" value="261">Madagascar (+261)</option>
                                <option data-countryCode="MW" value="265">Malawi (+265)</option>
                                <option data-countryCode="MY" value="60">Malaysia (+60)</option>
                                <option data-countryCode="MV" value="960">Maldives (+960)</option>
                                <option data-countryCode="ML" value="223">Mali (+223)</option>
                                <option data-countryCode="MT" value="356">Malta (+356)</option>
                                <option data-countryCode="MH" value="692">Marshall Islands (+692)</option>
                                <option data-countryCode="MQ" value="596">Martinique (+596)</option>
                                <option data-countryCode="MR" value="222">Mauritania (+222)</option>
                                <option data-countryCode="YT" value="269">Mayotte (+269)</option>
                                <option data-countryCode="MX" value="52">Mexico (+52)</option>
                                <option data-countryCode="FM" value="691">Micronesia (+691)</option>
                                <option data-countryCode="MD" value="373">Moldova (+373)</option>
                                <option data-countryCode="MC" value="377">Monaco (+377)</option>
                                <option data-countryCode="MN" value="976">Mongolia (+976)</option>
                                <option data-countryCode="MS" value="1664">Montserrat (+1664)</option>
                                <option data-countryCode="MA" value="212">Morocco (+212)</option>
                                <option data-countryCode="MZ" value="258">Mozambique (+258)</option>
                                <option data-countryCode="MN" value="95">Myanmar (+95)</option>
                                <option data-countryCode="NA" value="264">Namibia (+264)</option>
                                <option data-countryCode="NR" value="674">Nauru (+674)</option>
                                <option data-countryCode="NP" value="977">Nepal (+977)</option>
                                <option data-countryCode="NL" value="31">Netherlands (+31)</option>
                                <option data-countryCode="NC" value="687">New Caledonia (+687)</option>
                                <option data-countryCode="NZ" value="64">New Zealand (+64)</option>
                                <option data-countryCode="NI" value="505">Nicaragua (+505)</option>
                                <option data-countryCode="NE" value="227">Niger (+227)</option>
                                <option data-countryCode="NG" value="234">Nigeria (+234)</option>
                                <option data-countryCode="NU" value="683">Niue (+683)</option>
                                <option data-countryCode="NF" value="672">Norfolk Islands (+672)</option>
                                <option data-countryCode="NP" value="670">Northern Marianas (+670)</option>
                                <option data-countryCode="NO" value="47">Norway (+47)</option>
                                <option data-countryCode="OM" value="968">Oman (+968)</option>
                                <option data-countryCode="PW" value="680">Palau (+680)</option>
                                <option data-countryCode="PA" value="507">Panama (+507)</option>
                                <option data-countryCode="PG" value="675">Papua New Guinea (+675)</option>
                                <option data-countryCode="PY" value="595">Paraguay (+595)</option>
                                <option data-countryCode="PE" value="51">Peru (+51)</option>
                                <option data-countryCode="PH" value="63">Philippines (+63)</option>
                                <option data-countryCode="PL" value="48">Poland (+48)</option>
                                <option data-countryCode="PT" value="351">Portugal (+351)</option>
                                <option data-countryCode="PR" value="1787">Puerto Rico (+1787)</option>
                                <option data-countryCode="QA" value="974">Qatar (+974)</option>
                                <option data-countryCode="RE" value="262">Reunion (+262)</option>
                                <option data-countryCode="RO" value="40">Romania (+40)</option>
                                <option data-countryCode="RU" value="7">Russia (+7)</option>
                                <option data-countryCode="RW" value="250">Rwanda (+250)</option>
                                <option data-countryCode="SM" value="378">San Marino (+378)</option>
                                <option data-countryCode="ST" value="239">Sao Tome &amp; Principe (+239)</option>
                                <option data-countryCode="SA" value="966">Saudi Arabia (+966)</option>
                                <option data-countryCode="SN" value="221">Senegal (+221)</option>
                                <option data-countryCode="CS" value="381">Serbia (+381)</option>
                                <option data-countryCode="SC" value="248">Seychelles (+248)</option>
                                <option data-countryCode="SL" value="232">Sierra Leone (+232)</option>
                                <option data-countryCode="SG" value="65">Singapore (+65)</option>
                                <option data-countryCode="SK" value="421">Slovak Republic (+421)</option>
                                <option data-countryCode="SI" value="386">Slovenia (+386)</option>
                                <option data-countryCode="SB" value="677">Solomon Islands (+677)</option>
                                <option data-countryCode="SO" value="252">Somalia (+252)</option>
                                <option data-countryCode="ZA" value="27">South Africa (+27)</option>
                                <option data-countryCode="ES" value="34">Spain (+34)</option>
                                <option data-countryCode="LK" value="94">Sri Lanka (+94)</option>
                                <option data-countryCode="SH" value="290">St. Helena (+290)</option>
                                <option data-countryCode="KN" value="1869">St. Kitts (+1869)</option>
                                <option data-countryCode="SC" value="1758">St. Lucia (+1758)</option>
                                <option data-countryCode="SD" value="249">Sudan (+249)</option>
                                <option data-countryCode="SR" value="597">Suriname (+597)</option>
                                <option data-countryCode="SZ" value="268">Swaziland (+268)</option>
                                <option data-countryCode="SE" value="46">Sweden (+46)</option>
                                <option data-countryCode="CH" value="41">Switzerland (+41)</option>
                                <option data-countryCode="SI" value="963">Syria (+963)</option>
                                <option data-countryCode="TW" value="886">Taiwan (+886)</option>
                                <option data-countryCode="TJ" value="7">Tajikstan (+7)</option>
                                <option data-countryCode="TH" value="66">Thailand (+66)</option>
                                <option data-countryCode="TG" value="228">Togo (+228)</option>
                                <option data-countryCode="TO" value="676">Tonga (+676)</option>
                                <option data-countryCode="TT" value="1868">Trinidad &amp; Tobago (+1868)</option>
                                <option data-countryCode="TN" value="216">Tunisia (+216)</option>
                                <option data-countryCode="TR" value="90">Turkey (+90)</option>
                                <option data-countryCode="TM" value="7">Turkmenistan (+7)</option>
                                <option data-countryCode="TM" value="993">Turkmenistan (+993)</option>
                                <option data-countryCode="TC" value="1649">Turks &amp; Caicos Islands (+1649)</option>
                                <option data-countryCode="TV" value="688">Tuvalu (+688)</option>
                                <option data-countryCode="UG" value="256">Uganda (+256)</option>
                                <option data-countryCode="GB" value="44">UK (+44)</option>
                                <option data-countryCode="UA" value="380">Ukraine (+380)</option>
                                <option data-countryCode="AE" value="971">United Arab Emirates (+971)</option>
                                <option data-countryCode="UY" value="598">Uruguay (+598)</option>
                                <option data-countryCode="US" value="1">USA (+1)</option>
                                <option data-countryCode="UZ" value="7">Uzbekistan (+7)</option>
                                <option data-countryCode="VU" value="678">Vanuatu (+678)</option>
                                <option data-countryCode="VA" value="379">Vatican City (+379)</option>
                                <option data-countryCode="VE" value="58">Venezuela (+58)</option>
                                <option data-countryCode="VN" value="84">Vietnam (+84)</option>
                                <option data-countryCode="VG" value="84">Virgin Islands - British (+1284)</option>
                                <option data-countryCode="VI" value="84">Virgin Islands - US (+1340)</option>
                                <option data-countryCode="WF" value="681">Wallis &amp; Futuna (+681)</option>
                                <option data-countryCode="YE" value="969">Yemen (North)(+969)</option>
                                <option data-countryCode="YE" value="967">Yemen (South)(+967)</option>
                                <option data-countryCode="ZM" value="260">Zambia (+260)</option>
                                <option data-countryCode="ZW" value="263">Zimbabwe (+263)</option>
                            </optgroup>
                        </select>
                        <?php if(isset($data->phone)): ?>
                            <input type="number" name="phonenumber" value="<?php echo e($data->phone); ?>">
                        <?php else: ?>
                            <input type="number" name="phonenumber">
                        <?php endif; ?>
                    </div>
                    <div>
                        <label>Email: </label>
                        <?php if(isset($data->email)): ?>
                            <input type="email" name="email" class="form-contorl" value="<?php echo e($data->email); ?>">
                        <?php else: ?>
                            <input type="email" name="email" class="form-contorl">
                        <?php endif; ?>
                    </div>
                    <div>
                        <label>Marital Status</label>
                        <select name="martialstatus">
                            <?php if(isset($data->martialstatus)): ?>
                                <option selected value="<?php echo e($data->martialstatus); ?>"><?php echo e($data->martialstatus); ?></option>
                            <?php endif; ?>
                            <option>Married</option>
                            <option>Widowed</option>
                            <option>Separated</option>
                            <option>Divorced</option>
                            <option>Single</option>
                        </select>
                    </div>
                    <div>
                        <label>Employment Relationship: </label>
                        <select name="employmentrelationship">
                            <?php if(isset($data->employmentrelationship)): ?> <option selected value="<?php echo e($data->employmentrelationship); ?>"><?php echo e($data->employmentrelationship); ?></option> <?php endif; ?>
                            <option>Coworkers</option>
                            <option>Team Members</option>
                            <option>Work Friends</option>
                            <option>Manager/Direct Report</option>
                            <option>Office Spouse</option>
                            <option>Mentor/Mentee</option>
                            <option>Life Friends</option>
                        </select>
                    </div>
                    <div>
                        <?php if(isset($data->job)): ?>
                            <label>Job: </label>
                            <input type="text" name="job" class="form-control" value="<?php echo e($data->job); ?>">
                        <?php else: ?>
                            <input type="text" name="job" class="form-control">
                        <?php endif; ?>
                    </div>
                    <div>
                        <label>Payment Rhythm</label>
                        <select name="paymentrhythm">
                            <?php if(isset($data->paymentrhythm)): ?><option selected value="<?php echo e($data->paymentrhythm); ?>"><?php echo e($data->paymentrhythm); ?></option><?php endif; ?>
                            <option>Weekly</option>
                            <option>Mounth</option>
                            <option>Year</option>
                        </select>
                    </div>
                    <div>
                        <label>Amount Per Month</label>
                        <?php if(isset($data->amountpermonth)): ?>
                            <input type="number" name="amountpermonth" class="form-control" value="<?php echo e($data->amountpermonth); ?>">
                        <?php else: ?>
                            <input type="number" name="amountpermonth" class="form-control">
                        <?php endif; ?>

                    </div>
                    <div>
                        <label>Share Guarantee/Fund</label>
                        <select name="shareguaranteefund">
                            <?php
                                $j = 100;
                            ?>
                            <?php for($i = 1;$i<=100;$i++): ?>
                                
                                <option><?php echo e($i."/".--$j); ?></option>
                            <?php endfor; ?>

                        </select>

                    </div>
                    <div>
                        <label>Contract Start Date: </label>
                        <?php if(isset($data->contractstartdate)): ?>
                            <input type="date" name="contractstartdate" class="form-control" value="<?php echo e($data->contractstartdate); ?>">
                        <?php else: ?>
                            <input type="date" name="contractstartdate" class="form-control">
                        <?php endif; ?>
                    </div>
                    <div>
                        <?php if(isset($data->premiumwaiver)): ?>
                            <?php if($data->premiumwaiver == 'Yes'): ?>
                                <label>Premium Waiver: </label><br>
                                <input type="radio" name="premiumwaiver" value="Yes" checked>
                                <label for="premiumwaiver">Yes</label>
                            <?php else: ?>
                                <input type="radio" name="premiumwaiver" value="No" checked>
                                <label for="premiumwaiver">No</label>
                            <?php endif; ?>
                            <label>Premium Waiver: </label><br>
                            <input type="radio" name="premiumwaiver" value="Yes" >
                            <label for="premiumwaiver">Yes</label>
                            <input type="radio" name="premiumwaiver" value="No" >
                            <label for="premiumwaiver">No</label>
                        <?php endif; ?>
                    </div>
                    <div>
                        <?php if(isset($data->eupension)): ?>
                            <?php if($data->eupension == 'Yes'): ?>
                                <label>Eu Pension: </label><br>
                                <input type="radio" name="eupension" value="Yes" checked>
                                <label for="eupension">Yes</label>
                            <?php else: ?>
                                <input type="radio" name="eupension" value="No" checked>
                                <label for="eupension">No</label>
                            <?php endif; ?>
                            <label>Eu Pension: </label><br>
                            <input type="radio" name="eupension" value="Yes">
                            <label for="eupension">Yes</label>
                            <input type="radio" name="eupension" value="No">
                            <label for="eupension">No</label>
                        <?php endif; ?>
                    </div>
                    <div>
                        <?php if(isset($data->deathcapital)): ?>
                            <?php if($data->deathcapital == 'Yes'): ?>
                                <label>Death Capital: </label><br>
                                <input type="radio" name="deathcapital" value="Yes" checked>
                                <label for="deathcapital">Yes</label>
                            <?php else: ?>
                                <input type="radio" name="deathcapital" value="No" checked>
                                <label for="deathcapital">No</label>
                            <?php endif; ?>
                            <label>Death Capital: </label><br>
                            <input type="radio" name="deathcapital" value="Yes" >
                            <label for="deathcapital">Yes</label>
                            <input type="radio" name="deathcapital" value="No" >
                            <label for="deathcapital">No</label>
                        <?php endif; ?>
                    </div>
                    <div>

                        <?php if(isset($data->smoker)): ?>
                            <?php if($data->smoker == 'Yes'): ?>
                                <label>Smoker: </label><br>
                                <input type="radio" name="smoker" value="Yes" checked>
                                <label for="smoker">Yes</label>
                            <?php else: ?>
                                <input type="radio" name="smoker" value="No" checked>
                                <label for="smoker">No</label>
                            <?php endif; ?>
                            <label>Smoker: </label><br>
                            <input type="radio" name="smoker" value="Yes">
                            <label for="smoker">Yes</label>
                            <input type="radio" name="smoker" value="No">
                            <label for="smoker">No</label>
                        <?php endif; ?>
                    </div>
                    <div>
                        <label>Which Companies Should Make An Offer</label>
                        <?php if(isset($data->whichcompaniesshouldmakeanoffer)): ?>
                            <input type="text" name="whichcompaniesshouldmakeanoffer" class="form-control" value="<?php echo e($data->whichcompaniesshouldmakeanoffer); ?>">
                        <?php else: ?>
                            <input type="text" name="whichcompaniesshouldmakeanoffer" class="form-control">
                        <?php endif; ?>
                    </div>

                </div>
            </div>


            <div style="display: none" id="more">
                <h4>Household Contents And Personal Liability</h4>

                <input onclick="openCounteroffered()" type="button" value="Counteroffered" class="btn btn-primary">
                <input onclick="openNewPropertyInsurance()" type="button" value="New Property Insurance" class="btn btn-primary">
                <input onclick="openChoiceSociety()" type="button" value="Choose Society" class="btn btn-primary">

                <div id="counteroffered">

                </div>

                <div id="newrequest">

                </div>
                <div id="choosesociety">


                </div>
            </div>


            <input type="submit" class="mt-3 btn btn-primary" value="Save">
        </form>
    </div>
    </div>
    <script>
        cnt = 1;
        vehcnt = 1;
        counte = 1;
        newre = 1;
        chsc = 1;
        count = 1;
        function openHealth() {
            document.getElementById("health").style.display = "block";
            document.getElementById("car").style.display = "none";
            document.getElementById("finance").style.display = "none";
            document.getElementById("more").style.display = "none";
        }

        function openCar() {
            document.getElementById('health').style.display = "none";
            document.getElementById('car').style.display = "block";
            document.getElementById("finance").style.display = "none";
            document.getElementById("more").style.display = "none";


    function openNewVehicle() {
        if(vehcnt % 2 == 1){
        document.getElementById('newVehicle').innerHTML = ' <label>Upload vehicle ID</label> <?php if(isset($data->uploadvehicleid)): ?> <input class="form-control" type="file" name="uploadvehicleid" value="<?php echo e($data->uploadvehicleid); ?>"> <?php else: ?> <input class="form-control" type="file" name="uploadvehicleid"> <?php endif; ?> </div> <div> <h6>Lesing</h6> <input onclick="openYesCheckBox()" type="radio" name="leasing" id="yes" value="Yes"> <label for="yes">Yes</label> <div class="hide" id="leasingname"> <input type="text" name="leasingname" placeholder="Lesaing Name"> </div> <input type="radio" name="leasing" id="no" value="No"> <label for="no">No</label> </div> <br> <hr> <h4>Vahicle Information</h4> <div> <span>Purchase Year</span> <select name="yearpurchase"> <?php for($i = \Carbon\Carbon::now()->format("Y");$i>=1950;$i--): ?> <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option> <?php endfor; ?> </select> </div> <div> <label>First Commissioning</label> <?php if(isset($data->firstcommissioning)): ?> <input type="date" class="form-control" name="firstcommissioning" value="<?php echo e($data->firstcommissioning); ?>"> <?php else: ?> <input type="date" class="form-control" name="firstcommissioning"> <?php endif; ?>  </div> <div> <label>Start Insurance</label> <?php if(isset($data->startinsurance)): ?> <input type="date" class="form-control" name="startinsurance" value="<?php echo e($data->startinsurance); ?>"> <?php else: ?> <input type="date" class="form-control" name="startinsurance"> <?php endif; ?> </div> <div> <label>Kanton:</label> <select name="kanton"> <?php if(isset($data->kanton)): ?> <option selected value="<?php echo e($data->kanton); ?>"><?php echo e($data->kanton); ?></option> <?php endif; ?> <option>Zürich</option> <option>Bern / Berne</option> <option>Luzern</option> <option>Uri</option> <option>Schwyz</option> <option>Unterwalden</option> <option>Glarus</option> <option>Zug</option> <option>Freiburg / Fribourg</option> <option>Solothurn</option> <option>Basel</option> <option>Schaffhausen</option> <option>Appenzell</option> <option>Sankt Gallen</option> <option>Graubünden</option> <option>Aargau</option> <option>Thurgau</option> <option>Ticino</option> <option>Vaud</option> <option>Valais / Wallis</option> <option>Neuchâtel</option> <option>Genève</option> <option>Jura</option> </select> </div> <div> <label>KM-Stand</label> <?php if(isset($data->kmstand)): ?> <input class="form-control" type="number" name="kmstand" value="<?php echo e($data->kmstand); ?>"> <?php else: ?> <input class="form-control" type="number" name="kmstand"> <?php endif; ?> </div> <hr> <h4>Driver Information</h4> <div> <label>Date of issue of drivers license</label> <?php if(isset($data->dateofissueofdriverslicense)): ?> <input class="form-control" type="date" name="dateofissueofdriverslicense" value="<?php echo e($data->dateofissueofdriverslicense); ?>"> <?php else: ?> <input class="form-control" type="date" name="dateofissueofdriverslicense"> <?php endif; ?> </div> <div> <label>Nationality: </label> <?php if(isset($data->nationality)): ?> <input class="form-control" type="text" name="nationality" value="<?php echo e($data->nationality); ?>"> <?php else: ?> <input class="form-control" type="text" name="nationality"> <?php endif; ?> </div> <div> <label>Lenker? </label> <select name="lenker"> <?php if(isset($data->lenker)): ?> <option selected value="<?php echo e($data->lenker); ?>"><?php echo e($data->lenker); ?></option> <?php endif; ?> <option>Yes</option> <option>No</option> </select> </div> <hr> <h4>Desired Coverage</h4> <div> <label>Insurance</label> <select name="insurance"> <?php if(isset($data->insurance)): ?> <option selected value="<?php echo e($data->insurance); ?>"><?php echo e($data->insurance); ?></option> <?php endif; ?> <option>300</option> <option>500</option> <option>1000 (drivers under 25 years)</option> </select> </div> <div> <label>Deduction Part: </label> <select name="deductionpart"><?php if(isset($data->deductionpart)): ?> <option value="<?php echo e($data->deductionpart); ?>"><?php echo e($data->deductionpart); ?></option> <?php endif; ?> <?php for($i = 1000;$i<=20000;$i+=1000): ?> <option><?php echo e($i); ?></option> <?php endfor; ?> </select> </div> <div> <label>Things Carried: </label> <?php if(isset($data->thingscarried)): ?> <input type="text" class="form-control" name="thingscarried" value="<?php echo e($data->thingscarried); ?>"> <?php else: ?> <input type="text" class="form-control" name="thingscarried"> <?php endif; ?> </div> <div> <?php if(isset($data->partnergarage)): ?> <?php if($data->partnergarage == "Parter Garage"): ?> <label>Repair Shop: </label><br> <input type="radio" name="partnergarage" value="Parter Garage" checked> <label for="partnergarage">Partener Garage</label> <?php else: ?> <input type="radio" name="partnergarage" value="Free Choice" checked> <label for="partnergarage">Free Choice</label> <?php endif; ?> <label>Repair Shop: </label><br> <input type="radio" name="partnergarage" value="Parter Garage"> <label for="partnergarage">Partener Garage</label> <input type="radio" name="partnergarage" value="Free Choice"> <label for="partnergarage">Free Choice</label> <?php endif; ?> </div> <div> <?php if(isset($data->accidentcoverage)): ?> <?php if($data->accidentcoverage == "Yes"): ?> <label>Accident Coverage: </label><br> <input type="radio" name="accidentcoverage" value="Yes" checked> <label for="accidentcoverage">Yes</label> <?php else: ?> <input type="radio" name="accidentcoverage" value="No" checked> <label for="accidentcoverage">No</label> <?php endif; ?> <label>Accident Coverage: </label><br> <input type="radio" name="accidentcoverage" value="Yes"> <label for="accidentcoverage">Yes</label> <input type="radio" name="accidentcoverage" value="No"> <label for="accidentcoverage">No</label> <?php endif; ?> </div> <div> <?php if(isset($data->trafficrightsprotection)): ?> <?php if($data->trafficrightsprotection == "Yes"): ?> <label>Traffic Rights Protection: </label><br> <input type="radio" name="trafficrightsprotection" value="Yes" checked> <label for="trafficrightsprotection">Yes</label> <?php else: ?> <input type="radio" name="trafficrightsprotection" value="No" checked> <label for="trafficrightsprotection">No</label> <?php endif; ?> <label>Traffic Rights Protection: </label><br> <input type="radio" name="trafficrightsprotection" value="Yes"> <label for="trafficrightsprotection">Yes</label> <input type="radio" name="trafficrightsprotection" value="No"> <label for="trafficrightsprotection">No</label> <?php endif; ?> </div> <div> <?php if(isset($data->grossnegligenceprotection)): ?> <?php if($data->grossnegligenceprotection == "Yes"): ?> <label>Gross Negligence Protection: </label><br> <input type="radio" name="grossnegligenceprotection" value="Yes" checked> <label for="grossnegligenceprotection">Yes</label> <?php else: ?> <input type="radio" name="grossnegligenceprotection" value="No" checked> <label for="grossnegligenceprotection">No</label> <?php endif; ?> <label>Gross Negligence Protection: </label><br> <input type="radio" name="grossnegligenceprotection" value="Yes"> <label for="grossnegligenceprotection">Yes</label> <input type="radio" name="grossnegligenceprotection" value="No"> <label for="grossnegligenceprotection">No</label> <?php endif; ?> </div> <div> <?php if(isset($data->glassprotection)): ?> <?php if($data->glassprotection == "Yes"): ?> <label>Glass Protection: </label><br> <input type="radio" name="glassprotection" value="Yes" checked> <label for="glassprotection">Yes</label> <?php else: ?> <input type="radio" name="glassprotection" value="No" checked> <label for="glassprotection">No</label> <?php endif; ?> <label>Glass Protection: </label><br> <input type="radio" name="glassprotection" value="Yes"> <label for="glassprotection">Yes</label> <input type="radio" name="glassprotection" value="No"> <label for="glassprotection">No</label> <?php endif; ?> </div> <div> <?php if(isset($data->parkingdamage)): ?> <?php if($data->parkingdamage == "Yes"): ?> <label>Parking Damage: </label><br> <input type="radio" name="parkingdamage" value="Yes" checked> <label for="parkingdamage">Yes</label> <?php else: ?> <input type="radio" name="parkingdamage" value="No" checked> <label for="parkingdamage">No</label> <?php endif; ?> <label>Parking Damage: </label><br> <input type="radio" name="parkingdamage" value="Yes"> <label for="parkingdamage">Yes</label> <input type="radio" name="parkingdamage" value="No"> <label for="parkingdamage">No</label> <?php endif; ?> </div> <div> <?php if(isset($data->roadsideassistance)): ?> <?php if($data->roadsideassistance == "Yes"): ?> <label>24H Roadside Assistance: </label><br> <input type="radio" name="roadsideassistance" value="Yes" checked> <label for="roadsideassistance">Yes</label> <?php else: ?> <input type="radio" name="roadsideassistance" value="No" checked> <label for="roadsideassistance">No</label> <?php endif; ?> <label>24H Roadside Assistance: </label><br> <input type="radio" name="roadsideassistance" value="Yes" > <label for="roadsideassistance">Yes</label> <input type="radio" name="roadsideassistance" value="No" > <label for="roadsideassistance">No</label> <?php endif; ?> </div> <div> <label>Car Comment</label> <?php if(isset($data->carcomment)): ?> <input type="text" class="form-control" name="carcomment" value="<?php echo e($data->carcomment); ?>"> <?php else: ?> <input type="text" class="form-control" name="carcomment"> <?php endif; ?> <br> <input type="button" class="btn btn-info" onClick="openAnotherNewVehicle()" value="Add Another One">';

        }

        function openFinance() {
            document.getElementById('health').style.display = "none";
            document.getElementById('car').style.display = "none";
            document.getElementById("finance").style.display = "block";
            document.getElementById("more").style.display = "none";
        }

        function openMore() {
            document.getElementById('health').style.display = "none";
            document.getElementById('car').style.display = "none";
            document.getElementById("finance").style.display = "none";
            document.getElementById("more").style.display = "block";
        }

        function openCounterOffer() {


            if(cnt % 2 == 1)
                document.getElementById('counteroffer').innerHTML = '<?php if(isset($data->uploadpolice)): ?><input class="form-control" type="file" name="uploadpolice" value="<?php echo e($data->uploadpolice); ?>"> <?php else: ?> <input class="form-control" type="file" name="uploadpolice">   <?php endif; ?> <?php if(isset($data->comment)): ?> <input type="text" name="comment" placeholder="Comment" value="<?php echo e($data->comment); ?>"> <?php else: ?> <input type="text" name="comment" placeholder="Comment"> <?php endif; ?>';
            else
                document.getElementById('counteroffer').innerHTML = "";


            if(cnt % 2 == 1){
                document.getElementById('counteroffer').innerHTML = '<?php if(isset($data->uploadpolice)): ?><input class="form-control" type="file" name="uploadpolice" value="<?php echo e($data->uploadpolice); ?>"> <?php else: ?> <input class="form-control" type="file" name="uploadpolice">   <?php endif; ?> <?php if(isset($data->comment)): ?> <input type="text" name="comment" placeholder="Comment" value="<?php echo e($data->comment); ?>"> <?php else: ?> <input type="text" name="comment" placeholder="Comment"> <?php endif; ?>';}
            else{
                document.getElementById('counteroffer').innerHTML = "";}

            cnt++;
            vehcnt = 1;
            document.getElementById('newVehicle').innerHTML = "";
            document.getElementById('anotherNewVehicle').innerHTML = '';
        }

        function openNewVehicle() {
            if(vehcnt % 2 == 1){
                document.getElementById('newVehicle').innerHTML = ' <label>Upload vehicle ID</label> <?php if(isset($data->uploadvehicleid)): ?> <input class="form-control" type="file" name="uploadvehicleid" value="<?php echo e($data->uploadvehicleid); ?>"> <?php else: ?> <input class="form-control" type="file" name="uploadvehicleid"> <?php endif; ?> </div> <div> <h6>Lesing</h6> <input onclick="openYesCheckBox()" type="radio" name="leasing" id="yes" value="Yes"> <label for="yes">Yes</label> <div class="hide" id="leasingname"> <input type="text" name="leasingname" placeholder="Lesaing Name"> </div> <input type="radio" name="leasing" id="no" value="No"> <label for="no">No</label> </div> <br> <hr> <h4>Vahicle Information</h4> <div> <span>Purchase Year</span> <select name="yearpurchase"> <?php for($i = \Carbon\Carbon::now()->format("Y");$i>=1950;$i--): ?> <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option> <?php endfor; ?> </select> </div> <div> <label>First Commissioning</label> <?php if(isset($data->firstcommissioning)): ?> <input type="date" class="form-control" name="firstcommissioning" value="<?php echo e($data->firstcommissioning); ?>"> <?php else: ?> <input type="date" class="form-control" name="firstcommissioning"> <?php endif; ?>  </div> <div> <label>Start Insurance</label> <?php if(isset($data->startinsurance)): ?> <input type="date" class="form-control" name="startinsurance" value="<?php echo e($data->startinsurance); ?>"> <?php else: ?> <input type="date" class="form-control" name="startinsurance"> <?php endif; ?> </div> <div> <label>Kanton:</label> <select name="kanton"> <?php if(isset($data->kanton)): ?> <option selected value="<?php echo e($data->kanton); ?>"><?php echo e($data->kanton); ?></option> <?php endif; ?> <option>Zürich</option> <option>Bern / Berne</option> <option>Luzern</option> <option>Uri</option> <option>Schwyz</option> <option>Unterwalden</option> <option>Glarus</option> <option>Zug</option> <option>Freiburg / Fribourg</option> <option>Solothurn</option> <option>Basel</option> <option>Schaffhausen</option> <option>Appenzell</option> <option>Sankt Gallen</option> <option>Graubünden</option> <option>Aargau</option> <option>Thurgau</option> <option>Ticino</option> <option>Vaud</option> <option>Valais / Wallis</option> <option>Neuchâtel</option> <option>Genève</option> <option>Jura</option> </select> </div> <div> <label>KM-Stand</label> <?php if(isset($data->kmstand)): ?> <input class="form-control" type="number" name="kmstand" value="<?php echo e($data->kmstand); ?>"> <?php else: ?> <input class="form-control" type="number" name="kmstand"> <?php endif; ?> </div> <hr> <h4>Driver Information</h4> <div> <label>Date of issue of drivers license</label> <?php if(isset($data->dateofissueofdriverslicense)): ?> <input class="form-control" type="date" name="dateofissueofdriverslicense" value="<?php echo e($data->dateofissueofdriverslicense); ?>"> <?php else: ?> <input class="form-control" type="date" name="dateofissueofdriverslicense"> <?php endif; ?> </div> <div> <label>Nationality: </label> <?php if(isset($data->nationality)): ?> <input class="form-control" type="text" name="nationality" value="<?php echo e($data->nationality); ?>"> <?php else: ?> <input class="form-control" type="text" name="nationality"> <?php endif; ?> </div> <div> <label>Lenker? </label> <select name="lenker"> <?php if(isset($data->lenker)): ?> <option selected value="<?php echo e($data->lenker); ?>"><?php echo e($data->lenker); ?></option> <?php endif; ?> <option>Yes</option> <option>No</option> </select> </div> <hr> <h4>Desired Coverage</h4> <div> <label>Insurance</label> <select name="insurance"> <?php if(isset($data->insurance)): ?> <option selected value="<?php echo e($data->insurance); ?>"><?php echo e($data->insurance); ?></option> <?php endif; ?> <option>300</option> <option>500</option> <option>1000 (drivers under 25 years)</option> </select> </div> <div> <label>Deduction Part: </label> <select name="deductionpart"><?php if(isset($data->deductionpart)): ?> <option value="<?php echo e($data->deductionpart); ?>"><?php echo e($data->deductionpart); ?></option> <?php endif; ?> <?php for($i = 1000;$i<=20000;$i+=1000): ?> <option><?php echo e($i); ?></option> <?php endfor; ?> </select> </div> <div> <label>Things Carried: </label> <?php if(isset($data->thingscarried)): ?> <input type="text" class="form-control" name="thingscarried" value="<?php echo e($data->thingscarried); ?>"> <?php else: ?> <input type="text" class="form-control" name="thingscarried"> <?php endif; ?> </div> <div> <?php if(isset($data->partnergarage)): ?> <?php if($data->partnergarage == "Parter Garage"): ?> <label>Repair Shop: </label><br> <input type="radio" name="partnergarage" value="Parter Garage" checked> <label for="partnergarage">Partener Garage</label> <?php else: ?> <input type="radio" name="partnergarage" value="Free Choice" checked> <label for="partnergarage">Free Choice</label> <?php endif; ?> <label>Repair Shop: </label><br> <input type="radio" name="partnergarage" value="Parter Garage"> <label for="partnergarage">Partener Garage</label> <input type="radio" name="partnergarage" value="Free Choice"> <label for="partnergarage">Free Choice</label> <?php endif; ?> </div> <div> <?php if(isset($data->accidentcoverage)): ?> <?php if($data->accidentcoverage == "Yes"): ?> <label>Accident Coverage: </label><br> <input type="radio" name="accidentcoverage" value="Yes" checked> <label for="accidentcoverage">Yes</label> <?php else: ?> <input type="radio" name="accidentcoverage" value="No" checked> <label for="accidentcoverage">No</label> <?php endif; ?> <label>Accident Coverage: </label><br> <input type="radio" name="accidentcoverage" value="Yes"> <label for="accidentcoverage">Yes</label> <input type="radio" name="accidentcoverage" value="No"> <label for="accidentcoverage">No</label> <?php endif; ?> </div> <div> <?php if(isset($data->trafficrightsprotection)): ?> <?php if($data->trafficrightsprotection == "Yes"): ?> <label>Traffic Rights Protection: </label><br> <input type="radio" name="trafficrightsprotection" value="Yes" checked> <label for="trafficrightsprotection">Yes</label> <?php else: ?> <input type="radio" name="trafficrightsprotection" value="No" checked> <label for="trafficrightsprotection">No</label> <?php endif; ?> <label>Traffic Rights Protection: </label><br> <input type="radio" name="trafficrightsprotection" value="Yes"> <label for="trafficrightsprotection">Yes</label> <input type="radio" name="trafficrightsprotection" value="No"> <label for="trafficrightsprotection">No</label> <?php endif; ?> </div> <div> <?php if(isset($data->grossnegligenceprotection)): ?> <?php if($data->grossnegligenceprotection == "Yes"): ?> <label>Gross Negligence Protection: </label><br> <input type="radio" name="grossnegligenceprotection" value="Yes" checked> <label for="grossnegligenceprotection">Yes</label> <?php else: ?> <input type="radio" name="grossnegligenceprotection" value="No" checked> <label for="grossnegligenceprotection">No</label> <?php endif; ?> <label>Gross Negligence Protection: </label><br> <input type="radio" name="grossnegligenceprotection" value="Yes"> <label for="grossnegligenceprotection">Yes</label> <input type="radio" name="grossnegligenceprotection" value="No"> <label for="grossnegligenceprotection">No</label> <?php endif; ?> </div> <div> <?php if(isset($data->glassprotection)): ?> <?php if($data->glassprotection == "Yes"): ?> <label>Glass Protection: </label><br> <input type="radio" name="glassprotection" value="Yes" checked> <label for="glassprotection">Yes</label> <?php else: ?> <input type="radio" name="glassprotection" value="No" checked> <label for="glassprotection">No</label> <?php endif; ?> <label>Glass Protection: </label><br> <input type="radio" name="glassprotection" value="Yes"> <label for="glassprotection">Yes</label> <input type="radio" name="glassprotection" value="No"> <label for="glassprotection">No</label> <?php endif; ?> </div> <div> <?php if(isset($data->parkingdamage)): ?> <?php if($data->parkingdamage == "Yes"): ?> <label>Parking Damage: </label><br> <input type="radio" name="parkingdamage" value="Yes" checked> <label for="parkingdamage">Yes</label> <?php else: ?> <input type="radio" name="parkingdamage" value="No" checked> <label for="parkingdamage">No</label> <?php endif; ?> <label>Parking Damage: </label><br> <input type="radio" name="parkingdamage" value="Yes"> <label for="parkingdamage">Yes</label> <input type="radio" name="parkingdamage" value="No"> <label for="parkingdamage">No</label> <?php endif; ?> </div> <div> <?php if(isset($data->roadsideassistance)): ?> <?php if($data->roadsideassistance == "Yes"): ?> <label>24H Roadside Assistance: </label><br> <input type="radio" name="roadsideassistance" value="Yes" checked> <label for="roadsideassistance">Yes</label> <?php else: ?> <input type="radio" name="roadsideassistance" value="No" checked> <label for="roadsideassistance">No</label> <?php endif; ?> <label>24H Roadside Assistance: </label><br> <input type="radio" name="roadsideassistance" value="Yes" > <label for="roadsideassistance">Yes</label> <input type="radio" name="roadsideassistance" value="No" > <label for="roadsideassistance">No</label> <?php endif; ?> </div> <div> <label>Car Comment</label> <?php if(isset($data->carcomment)): ?> <input type="text" class="form-control" name="carcomment" value="<?php echo e($data->carcomment); ?>"> <?php else: ?> <input type="text" class="form-control" name="carcomment"> <?php endif; ?> <br> <input type="button" class="btn btn-info" onClick="openAnotherNewVehicle()" value="Add Another One">';
            }
            else{
                document.getElementById('newVehicle').innerHTML = "";}
            vehcnt++;
            cnt = 1;
            document.getElementById('counteroffer').innerHTML = "";
            document.getElementById('anotherNewVehicle').innerHTML = '';

        }

        function openYesCheckBox() {
            document.getElementById('leasingname').classList.toggle('hide');
        }


        function openCounteroffered() {
            if(counte % 2 == 1){
                document.getElementById('counteroffered').innerHTML = ' <h4>Counteroffer</h4>  <div>      <label>Upload Police</label> <?php if(isset($data->uploadpolice2)): ?><input type="file" name="uploadpolice2" class="form-control" value="<?php echo e($data->uploadpolice2); ?>"><?php else: ?>  <input type="file" name="uploadpolice2" class="form-control"><?php endif; ?>   <label>Comment At Police: </label>       <?php if(isset($data->commentatpolice)): ?> <input type="text" name="commentatpolice" value="<?php echo e($data->commentatpolice); ?>"> <?php else: ?>  <input type="text" name="commentatpolice"> <?php endif; ?>  </div>';}
            else{
                document.getElementById('counteroffered').innerHTML = '';
            }
            counte++;
            document.getElementById('newrequest').innerHTML = "";
            document.getElementById('choosesociety').innerHTML = "";
            document.getElementById('anotherNewVehicle').innerHTML = '';
            newre = 1;
            chsc = 1;
        }

        function openNewPropertyInsurance() {
            if(newre % 2 == 1){
                document.getElementById('newrequest').innerHTML = '<h4>New Request</h4><div><label>Number Of People</label><select name="numberofpeople"> <?php if(isset($data->numberofpeople)): ?> <option selected value="<?php echo e($data->numberofpeople); ?>"><?php echo e($data->numberofpeople); ?></option> <?php endif; ?> <?php for($i = 1;$i<=30;$i++): ?><option><?php echo e($i); ?></option><?php endfor; ?></select></div><div><label>Number Of Rooms</label><select name="numberofrooms"> <?php if(isset($data->numberofrooms)): ?> <option selected value="<?php echo e($data->numberofrooms); ?>"><?php echo e($data->numberofrooms); ?></option> <?php endif; ?> <?php for($i = 1;$i<=30;$i++): ?><option><?php echo e($i); ?></option><?php endfor; ?></select></div><div><label>Insuranceamount: </label> <?php if(isset($data->insurance)): ?> <input type="number" name="insuranceamount" class="form-control" value="<?php echo e($data->insuranceamount); ?>"> <?php else: ?> <input type="number" name="insuranceamount" class="form-control"> <?php endif; ?> </div><div><label>Wished Additional Things: </label>     <?php if(isset($data->wishedadditionalthings)): ?>  <input type="text" name="wishedadditionalthings" class="form-control" value="<?php echo e($data->wishedadditionalthings); ?>"> <?php else: ?> <input type="text" name="wishedadditionalthings" class="form-control"> <?php endif; ?> </div><div><label>Private Liability: </label><br><?php if(isset($data->privateliability)): ?>  <?php if($data->privateliability == "Yes"): ?><input type="radio" name="privateliability" value="Yes" checked><label for="privateliability">Yes</label><?php else: ?><input type="radio" name="privateliability" value="No" checked><label for="privateliability">No</label><?php endif; ?> <?php else: ?><input type="radio" name="privateliability" value="Yes" ><label for="privateliability">Yes</label><input type="radio" name="privateliability" value="No" ><label for="privateliability">No</label><?php endif; ?> </div>';
            }
            else{
                document.getElementById('newrequest').innerHTML = "";
            }
            newre++;
            document.getElementById('counteroffered').innerHTML = '';

    function openNewPropertyInsurance() {
        if(newre % 2 == 1){
        document.getElementById('newrequest').innerHTML = '<h4>New Request</h4><div><label>Number Of People</label><select name="numberofpeople"> <?php if(isset($data->numberofpeople)): ?> <option selected value="<?php echo e($data->numberofpeople); ?>"><?php echo e($data->numberofpeople); ?></option> <?php endif; ?> <?php for($i = 1;$i<=30;$i++): ?><option><?php echo e($i); ?></option><?php endfor; ?></select></div><div><label>Number Of Rooms</label><select name="numberofrooms"> <?php if(isset($data->numberofrooms)): ?> <option selected value="<?php echo e($data->numberofrooms); ?>"><?php echo e($data->numberofrooms); ?></option> <?php endif; ?> <?php for($i = 1;$i<=30;$i++): ?><option><?php echo e($i); ?></option><?php endfor; ?></select></div><div><label>Insuranceamount: </label> <?php if(isset($data->insurance)): ?> <input type="number" name="insuranceamount" class="form-control" value="<?php echo e($data->insuranceamount); ?>"> <?php else: ?> <input type="number" name="insuranceamount" class="form-control"> <?php endif; ?> </div><div><label>Wished Additional Things: </label>     <?php if(isset($data->wishedadditionalthings)): ?>  <input type="text" name="wishedadditionalthings" class="form-control" value="<?php echo e($data->wishedadditionalthings); ?>"> <?php else: ?> <input type="text" name="wishedadditionalthings" class="form-control"> <?php endif; ?> </div><div><label>Private Liability: </label><br><?php if(isset($data->privateliability)): ?>  <?php if($data->privateliability == "Yes"): ?><input type="radio" name="privateliability" value="Yes" checked><label for="privateliability">Yes</label><?php else: ?><input type="radio" name="privateliability" value="No" checked><label for="privateliability">No</label><?php endif; ?> <?php else: ?><input type="radio" name="privateliability" value="Yes" ><label for="privateliability">Yes</label><input type="radio" name="privateliability" value="No" ><label for="privateliability">No</label><?php endif; ?> </div>';
        }
        else{
        document.getElementById('newrequest').innerHTML = "";
    }
    newre++;
    document.getElementById('counteroffered').innerHTML = '';
    document.getElementById('choosesociety').innerHTML = "";
    document.getElementById('anotherNewVehicle').innerHTML = '';
    counte = 1;
    chsc = 1;
    }

    function openChoiceSociety() {
        if(chsc % 2 == 1) {
            document.getElementById('choosesociety').innerHTML = '<div> <h4>Legal Protection Insurance</h4> <div> <label>Society</label> <?php if(isset($data->society)): ?> <input type="text" name="society" class="form-control" value="<?php echo e($data->society); ?>"> <?php else: ?> <input type="text" name="society" class="form-control"> <?php endif; ?> </div> <div> <label>Number Of People at Insurance</label> <select name="numberofpeopleinsurance"> <?php if(isset($data->numberofpeopleinsurance)): ?> <option selected value="<?php echo e($data->numberofpeopleinsurance); ?>"><?php echo e($data->numberofpeopleinsurance); ?></option> <?php endif; ?> <?php for($i = 1;$i<=30;$i++): ?> <option><?php echo e($i); ?></option><?php endfor; ?></select> </div> </div>'
        }else{

            document.getElementById('choosesociety').innerHTML = "";
            document.getElementById('anotherNewVehicle').innerHTML = '';
            counte = 1;
            chsc = 1;
        }

        function openChoiceSociety() {
            if(chsc % 2 == 1) {
                document.getElementById('choosesociety').innerHTML = '<div> <h4>Legal Protection Insurance</h4> <div> <label>Society</label> <?php if(isset($data->society)): ?> <input type="text" name="society" class="form-control" value="<?php echo e($data->society); ?>"> <?php else: ?> <input type="text" name="society" class="form-control"> <?php endif; ?> </div> <div> <label>Number Of People at Insurance</label> <select name="numberofpeopleinsurance"> <?php if(isset($data->numberofpeopleinsurance)): ?> <option selected value="<?php echo e($data->numberofpeopleinsurance); ?>"><?php echo e($data->numberofpeopleinsurance); ?></option> <?php endif; ?> <?php for($i = 1;$i<=30;$i++): ?> <option><?php echo e($i); ?></option><?php endfor; ?></select> </div> </div>'
            }else{
                document.getElementById('choosesociety').innerHTML = "";
            }
            chsc++;
            document.getElementById('counteroffered').innerHTML = "";
            document.getElementById('newrequest').innerHTML = "";
            document.getElementById('anotherNewVehicle').innerHTML = '';
            counte = 1;
            newre = 1;
        }
        function openAnotherNewVehicle(){

            document.getElementById('anotherNewVehicle').innerHTML += '<div id="counter' + count +'"></div>';

                document.getElementById('counter'+ count).innerHTML +=    ' <label>Upload vehicle ID</label> <?php if(isset($data->uploadvehicleid)): ?> <input class="form-control" type="file" name="uploadvehicleid'+ count+ '" value="<?php echo e($data->uploadvehicleid); ?>"> <?php else: ?> <input class="form-control" type="file" name="uploadvehicleid'+ count+ '"> <?php endif; ?> </div> <div> <h6>Lesing</h6> <input onclick="openYesCheckBox()" type="radio" name="leasing'+ count+ '" id="yes" value="Yes"> <label for="yes">Yes</label> <div class="hide" id="leasingname"> <input type="text" name="leasingname'+ count+ '" placeholder="Lesaing Name"> </div> <input type="radio" name="leasing'+ count+ '" id="no" value="No"> <label for="no">No</label> </div> <br> <hr> <h4>Vahicle Information</h4> <div> <span>Purchase Year</span> <select name="yearpurchase'+ count+ '"> <?php for($i = \Carbon\Carbon::now()->format("Y");$i>=1950;$i--): ?> <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option> <?php endfor; ?> </select> </div> <div> <label>First Commissioning</label>  <input type="date" class="form-control" name="firstcommissioning'+count+'">  </div> <div> <label>Start Insurance</label> <input type="date" class="form-control" name="startinsurance'+ count+ '"> </div> <div> <label>Kanton:</label> <select name="kanton"> <?php if(isset($data->kanton)): ?> <option selected value="<?php echo e($data->kanton); ?>"><?php echo e($data->kanton); ?></option> <?php endif; ?> <option>Zürich</option> <option>Bern / Berne</option> <option>Luzern</option> <option>Uri</option> <option>Schwyz</option> <option>Unterwalden</option> <option>Glarus</option> <option>Zug</option> <option>Freiburg / Fribourg</option> <option>Solothurn</option> <option>Basel</option> <option>Schaffhausen</option> <option>Appenzell</option> <option>Sankt Gallen</option> <option>Graubünden</option> <option>Aargau</option> <option>Thurgau</option> <option>Ticino</option> <option>Vaud</option> <option>Valais / Wallis</option> <option>Neuchâtel</option> <option>Genève</option> <option>Jura</option> </select> </div> <div> <label>KM-Stand</label> <?php if(isset($data->kmstand)): ?> <input class="form-control" type="number" name="kmstand'+ count+ '" value="<?php echo e($data->kmstand); ?>' + count + '"> </div> <hr> <h4>Driver Information</h4> <div> <label>Date of issue of drivers license</label> <input class="form-control" type="date" name="dateofissueofdriverslicense'+ count+ '" value="<?php echo e($data->dateofissueofdriverslicense); ?>"> </div> <div> <label>Nationality: </label>  <input class="form-control" type="text" name="nationality'+ count+ '" value="<?php echo e($data->nationality); ?>"> </div> <div> <label>Lenker? </label> <select name="lenker'+ count+ '"> <option selected value="<?php echo e($data->lenker); ?>"><?php echo e($data->lenker); ?></option> <option>Yes</option> <option>No</option> </select> </div> <hr> <h4>Desired Coverage</h4> <div> <label>Insurance</label> <select name="insurance'+ count+ '"> <option selected value="<?php echo e($data->insurance); ?>"><?php echo e($data->insurance); ?></option> <option>300</option> <option>500</option> <option>1000 (drivers under 25 years)</option> </select> </div> <div> <label>Deduction Part: </label> <select name="deductionpart'+ count+ '"> <?php for($i = 1000;$i<=20000;$i+=1000): ?> <option selected value="<?php echo e($data->deductionpart); ?>"><?php echo e($data->deductionpart); ?></option> <option><?php echo e($i); ?></option> <?php endfor; ?> </select> </div> <div> <label>Things Carried: </label> <input type="text" class="form-control" name="thingscarried'+ count+ '" value="<?php echo e($data->thingscarried); ?>"> </div> <div> <?php if(isset($data->partnergarage)): ?> <?php if($data->partnergarage == "Parter Garage"): ?> <label>Repair Shop: </label><br> <input type="radio" name="partnergarage'+ count+ '" value="Parter Garage" checked> <label for="partnergarage">Partener Garage</label> <?php else: ?> <input type="radio" name="partnergarage'+ count+ '" value="Free Choice" checked> <label for="partnergarage">Free Choice</label> <?php endif; ?> <label>Repair Shop: </label><br> <input type="radio" name="partnergarage'+ count+ '" value="Parter Garage"> <label for="partnergarage">Partener Garage</label> <input type="radio" name="partnergarage'+ count+ '" value="Free Choice"> <label for="partnergarage">Free Choice</label> <?php endif; ?> </div> <div> <?php if(isset($data->accidentcoverage)): ?> <?php if($data->accidentcoverage == "Yes"): ?> <label>Accident Coverage: </label><br> <input type="radio" name="accidentcoverage'+ count+ '" value="Yes" checked> <label for="accidentcoverage">Yes</label> <?php else: ?> <input type="radio" name="accidentcoverage'+ count+ '" value="No" checked> <label for="accidentcoverage">No</label> <?php endif; ?> <label>Accident Coverage: </label><br> <input type="radio" name="accidentcoverage'+ count+ '" value="Yes"> <label for="accidentcoverage">Yes</label> <input type="radio" name="accidentcoverage'+ count+ '" value="No"> <label for="accidentcoverage">No</label> <?php endif; ?> </div> <div> <?php if(isset($data->trafficrightsprotection)): ?> <?php if($data->trafficrightsprotection == "Yes"): ?> <label>Traffic Rights Protection: </label><br> <input type="radio" name="trafficrightsprotection'+ count+ '" value="Yes" checked> <label for="trafficrightsprotection">Yes</label> <?php else: ?> <input type="radio" name="trafficrightsprotection'+ count+ '" value="No" checked> <label for="trafficrightsprotection">No</label> <?php endif; ?> <label>Traffic Rights Protection: </label><br> <input type="radio" name="trafficrightsprotection'+ count+ '" value="Yes"> <label for="trafficrightsprotection">Yes</label> <input type="radio" name="trafficrightsprotection'+ count+ '" value="No"> <label for="trafficrightsprotection">No</label> <?php endif; ?> </div> <div> <?php if(isset($data->grossnegligenceprotection)): ?> <?php if($data->grossnegligenceprotection == "Yes"): ?> <label>Gross Negligence Protection: </label><br> <input type="radio" name="grossnegligenceprotection'+ count+ '" value="Yes" checked> <label for="grossnegligenceprotection">Yes</label> <?php else: ?> <input type="radio" name="grossnegligenceprotection'+ count+ '" value="No" checked> <label for="grossnegligenceprotection">No</label> <?php endif; ?> <label>Gross Negligence Protection: </label><br> <input type="radio" name="grossnegligenceprotection'+ count+ '" value="Yes"> <label for="grossnegligenceprotection">Yes</label> <input type="radio" name="grossnegligenceprotection'+ count+ '" value="No"> <label for="grossnegligenceprotection">No</label> <?php endif; ?> </div> <div> <?php if(isset($data->glassprotection)): ?> <?php if($data->glassprotection == "Yes"): ?> <label>Glass Protection: </label><br> <input type="radio" name="glassprotection'+ count+ '" value="Yes" checked> <label for="glassprotection">Yes</label> <?php else: ?> <input type="radio" name="glassprotection'+ count+ '" value="No" checked> <label for="glassprotection">No</label> <?php endif; ?> <label>Glass Protection: </label><br> <input type="radio" name="glassprotection'+ count+ '" value="Yes"> <label for="glassprotection">Yes</label> <input type="radio" name="glassprotection'+ count+ '" value="No"> <label for="glassprotection">No</label> <?php endif; ?> </div> <div> <?php if(isset($data->parkingdamage)): ?> <?php if($data->parkingdamage == "Yes"): ?> <label>Parking Damage: </label><br> <input type="radio" name="parkingdamage'+ count+ '" value="Yes" checked> <label for="parkingdamage">Yes</label> <?php else: ?> <input type="radio" name="parkingdamage'+ count+ '" value="No" checked> <label for="parkingdamage">No</label> <?php endif; ?> <label>Parking Damage: </label><br> <input type="radio" name="parkingdamage'+ count+ '" value="Yes"> <label for="parkingdamage">Yes</label> <input type="radio" name="parkingdamage'+ count+ '" value="No"> <label for="parkingdamage">No</label> <?php endif; ?> </div> <div> <?php if(isset($data->roadsideassistance)): ?> <?php if($data->roadsideassistance == "Yes"): ?> <label>24H Roadside Assistance: </label><br> <input type="radio" name="roadsideassistance'+ count+ '" value="Yes" checked> <label for="roadsideassistance">Yes</label> <?php else: ?> <input type="radio" name="roadsideassistance'+ count+ '" value="No" checked> <label for="roadsideassistance">No</label> <?php endif; ?> <label>24H Roadside Assistance: </label><br> <input type="radio" name="roadsideassistance'+ count+ '" value="Yes" > <label for="roadsideassistance">Yes</label> <input type="radio" name="roadsideassistance'+ count+ '" value="No" > <label for="roadsideassistance">No</label> <?php endif; ?> </div> <div> <label>Car Comment</label> <input type="text" class="form-control" name="carcomment'+ count+ '" value="<?php echo e($data->carcomment); ?>"> <br> <input type="button" class="btn btn-info" onClick="openAnotherNewVehicle()" value="Add Another One"><input type="button" class="btn btn-danger" onClick="deleteAnotherNewVehicle()" value="Delete">';

            count++;
            document.getElementById('count').value = count;
        }
        function deleteAnotherNewVehicle(){

            document.getElementById('counter'+ --count).innerHTML = '';
            document.getElementById('count').value = count;
        }
    </script>
    <style>
        .hide {
            display: none;
        }
    </style>
<?php $__env->stopSection(); ?>

</html>

<?php echo $__env->make('template.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kutiza\crm\resources\views/documentsform.blade.php ENDPATH**/ ?>