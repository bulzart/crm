<html>

<?php $__env->startSection('content'); ?>
<div class="col-12 text-center" style="background: #f7f7f7;">

    <form action="<?php echo e(route('costumers')); ?>">
        <input class="form-control" type="text" name="searchname" placeholder="Search...">
        <div class="d-inline">
        <input type="date" name="searchdate1">
        <input type="date" name="searchdate2">
        <input class="btn btn-success" type="submit" value="Save">
    </form>
    <a href="<?php echo e(route('searchword')); ?>" class="btn btn-info">A/Z</a>
</div>

    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="p-4" style="border-radius: 25px;margin-bottom: 10px; background: #fff;">
        <p style="font-size: 23px;"><?php echo e(ucfirst($dat->name)); ?> (<?php echo e($dat->birthday); ?>)</p>
      <?php if($dat->contracts != null): ?> <?php echo e($contracts[$dat->id]->con1); ?> <br> <?php echo e($contracts[$dat->id]->con2); ?> <?php endif; ?>




</div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>
</html>

<?php echo $__env->make('template.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kutiza\crm\resources\views/costumers.blade.php ENDPATH**/ ?>