
<?php $__env->startSection('content'); ?>
<div class="row">
<div class="col-md-8 col-lg-8 col-sm-12 col-xs-8 col-12">
<table>
    <tr>
        <th colspan="2">ID</th>
    <th>Name</th>

    <th colspan="2">People&nbsp;</th>
    <th>Came from</th>

    </tr>
<?php $__currentLoopData = $datesforconversation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
    <td><?php echo e($l->id); ?><td>
    <td><?php echo e($l->name); ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
    <td><?php echo e($l->count); ?>&nbsp;<td>
        <td><?php if($l->campaign != null): ?><?php echo e($l->campaign->name); ?><?php else: ?> Registered <?php endif; ?></td>

    
       <td><a href="<?php echo e(route('alead',$l->id)); ?>" class="btn text-light" style="background-color: #4D3FD3;">Join</a><td>
           
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php if($datesforconversation->count() > 1): ?>
    <div class="d-flex justify-content-center mt-4"><nav role="navigation" aria-label="Pagination Navigation" class="flex items-center justify-between">
        <?php if($datesforconversation->currentPage() > 1): ?>
        <span> <a href="<?php echo e(route('dates',['page' => $datesforconversation->currentPage() -1])); ?>" class="relative inline-flex items-center px-4 py-2 ml-3 text-sm font-medium text-gray-700 bg-white border border-gray-300 leading-5 rounded-md hover:text-gray-500 focus:outline-none focus:ring ring-gray-300 focus:border-blue-300 active:bg-gray-100 active:text-gray-700 transition ease-in-out duration-150"></span>
        « Previous
            <?php endif; ?>
                   
                </span> <a href="<?php echo e(route('dates',['page' => $datesforconversation->currentPage() +1 ,])); ?>" class="relative inline-flex items-center px-4 py-2 ml-3 text-sm font-medium text-gray-700 bg-white border border-gray-300 leading-5 rounded-md hover:text-gray-500 focus:outline-none focus:ring ring-gray-300 focus:border-blue-300 active:bg-gray-100 active:text-gray-700 transition ease-in-out duration-150">
                    Next »
                </a></div> <div class="hidden sm:flex-1 sm:flex sm:items-center sm:justify-between"><div><p class="text-sm text-gray-700 leading-5">
                
                </p></div> <div></div></div></nav>
                <?php endif; ?>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kutiza\crm\resources\views/dates.blade.php ENDPATH**/ ?>